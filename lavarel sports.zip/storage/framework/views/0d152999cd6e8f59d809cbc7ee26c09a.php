<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    
    <title><?php echo e($meta['title'] ?? config('app.name')); ?></title>
    <meta name="description" content="<?php echo e($meta['description'] ?? ''); ?>">
    <?php if(isset($meta['canonical'])): ?>
    <link rel="canonical" href="<?php echo e($meta['canonical']); ?>">
    <?php endif; ?>

    
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e($meta['title'] ?? config('app.name')); ?>">
    <meta property="og:description" content="<?php echo e($meta['description'] ?? ''); ?>">
    <meta property="og:url" content="<?php echo e($meta['canonical'] ?? url()->current()); ?>">
    <?php if(isset($meta['og_image'])): ?>
    <meta property="og:image" content="<?php echo e($meta['og_image']); ?>">
    <?php endif; ?>
    <meta property="og:site_name" content="<?php echo e($meta['site_name'] ?? config('app.name')); ?>">

    
    <meta name="twitter:card" content="<?php echo e($meta['twitter_card'] ?? 'summary_large_image'); ?>">
    <meta name="twitter:title" content="<?php echo e($meta['title'] ?? config('app.name')); ?>">
    <meta name="twitter:description" content="<?php echo e($meta['description'] ?? ''); ?>">
    <?php if(isset($meta['og_image'])): ?>
    <meta name="twitter:image" content="<?php echo e($meta['og_image']); ?>">
    <?php endif; ?>

    
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>


<div class="ad-zone ad-header">
    <?php echo app(\App\Services\AdManager::class)->renderSlot('header'); ?>

</div>


<nav class="navbar navbar-expand-lg navbar-dark sticky-top" id="main-nav">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="<?php echo e(route('home')); ?>">
            <span class="brand-icon">⚡</span>
            <?php echo e(config('app.name', 'SportStream')); ?>

        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">
                        <i class="bi bi-house-fill"></i> Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('home') && request('sport') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>?status=live">
                        <i class="bi bi-broadcast"></i> <span class="live-dot"></span> Live
                    </a>
                </li>
                <?php
                    $navItems = \App\Models\NavigationMenu::active()->forLocation('header')->rootLevel()->with('children')->get();
                ?>
                <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->children->count()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                                <?php if($item->icon): ?><i class="bi bi-<?php echo e($item->icon); ?>"></i> <?php endif; ?>
                                <?php echo e($item->label); ?>

                            </a>
                            <ul class="dropdown-menu dropdown-menu-dark">
                                <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a class="dropdown-item" href="<?php echo e($child->url); ?>" target="<?php echo e($child->target); ?>">
                                        <?php if($child->icon): ?><i class="bi bi-<?php echo e($child->icon); ?>"></i> <?php endif; ?>
                                        <?php echo e($child->label); ?>

                                    </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e($item->url); ?>" target="<?php echo e($item->target); ?>">
                                <?php if($item->icon): ?><i class="bi bi-<?php echo e($item->icon); ?>"></i> <?php endif; ?>
                                <?php echo e($item->label); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            
            <form class="d-flex me-3" action="<?php echo e(route('search')); ?>" method="GET">
                <div class="input-group">
                    <input class="form-control search-input" type="search" name="q"
                           value="<?php echo e(request('q')); ?>" placeholder="Search matches, teams...">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </form>

            <?php if(auth()->guard()->check()): ?>
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i> <?php echo e(auth()->user()->name); ?>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end">
                        <?php if(auth()->user()->is_admin): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>"><i class="bi bi-speedometer2"></i> Admin Panel</a></li>
                            <li><hr class="dropdown-divider"></li>
                        <?php endif; ?>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right"></i> Logout</button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-person"></i> Login
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>


<?php if (! empty(trim($__env->yieldContent('breadcrumbs')))): ?>
<div class="breadcrumb-bar">
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 py-2">
                <?php echo $__env->yieldContent('breadcrumbs'); ?>
            </ol>
        </nav>
    </div>
</div>
<?php endif; ?>


<main id="main-content">
    <?php if(session('success')): ?>
        <div class="container-fluid mt-3">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="container-fluid mt-3">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>


<footer class="site-footer mt-auto">
    
    <div class="ad-zone ad-footer">
        <?php echo app(\App\Services\AdManager::class)->renderSlot('footer'); ?>

    </div>

    <div class="footer-main">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5 class="footer-brand">⚡ <?php echo e(config('app.name', 'SportStream')); ?></h5>
                    <p class="text-muted">Your #1 destination for live sports streaming. Watch matches from around the world.</p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="bi bi-twitter-x"></i></a>
                        <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="social-link"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="social-link"><i class="bi bi-telegram"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h6 class="text-uppercase text-muted fw-bold mb-3">Quick Links</h6>
                    <ul class="list-unstyled footer-links">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('search')); ?>">Search Matches</a></li>
                        <?php $__currentLoopData = \App\Models\SitePage::active()->where('show_in_nav', true)->orderBy('sort_order')->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('page.show', $p->slug)); ?>"><?php echo e($p->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="col-lg-4 mb-4">
                    <h6 class="text-uppercase text-muted fw-bold mb-3">Footer Menu</h6>
                    <ul class="list-unstyled footer-links">
                        <?php $__currentLoopData = \App\Models\NavigationMenu::active()->forLocation('footer')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($fi->url); ?>" target="<?php echo e($fi->target); ?>"><?php echo e($fi->label); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <p class="text-muted mb-0 small">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'SportStream')); ?>. All rights reserved.</p>
                <p class="text-muted mb-0 small">For entertainment purposes only. We do not host any streams.</p>
            </div>
        </div>
    </div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\lebo\Downloads\lavarel sports\resources\views/layouts/app.blade.php ENDPATH**/ ?>