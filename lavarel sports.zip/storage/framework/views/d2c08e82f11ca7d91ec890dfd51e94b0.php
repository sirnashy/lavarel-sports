

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-3 px-lg-4">

    
    <?php if($featuredMatches->isNotEmpty()): ?>
    <section class="featured-section py-4">
        <div class="section-header d-flex justify-content-between align-items-center mb-3">
            <h2 class="section-title"><i class="bi bi-star-fill text-warning"></i> Featured Matches</h2>
        </div>
        <div class="row g-3">
            <?php $__currentLoopData = $featuredMatches->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo e(route('match.detail', $fm->match_id)); ?>" class="featured-card-link">
                    <div class="featured-card">
                        <div class="featured-badge">FEATURED</div>
                        <div class="featured-card-body">
                            <?php if($fm->thumbnail): ?>
                                <img src="<?php echo e($fm->thumbnail); ?>" alt="<?php echo e($fm->title); ?>" class="featured-thumb" loading="lazy">
                            <?php else: ?>
                                <div class="featured-thumb-placeholder"><i class="bi bi-play-circle-fill"></i></div>
                            <?php endif; ?>
                            <div class="featured-info">
                                <h5 class="featured-title"><?php echo e($fm->title ?: 'Featured Match'); ?></h5>
                                <?php if($fm->match_starts_at): ?>
                                <p class="featured-time"><i class="bi bi-clock"></i> <?php echo e($fm->match_starts_at->format('D, M j \\a\\t H:i')); ?></p>
                                <?php endif; ?>
                                <span class="btn btn-primary btn-sm"><i class="bi bi-play-fill"></i> Watch Now</span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php endif; ?>

    
    <div class="sport-filter-bar mb-4">
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <span class="text-muted small">Filter:</span>
            <a href="<?php echo e(route('home')); ?>" class="sport-pill <?php echo e(!$sportId ? 'active' : ''); ?>">All Sports</a>
            <?php $sportsData = $sports['data'] ?? $sports; ?>
            <?php $__currentLoopData = (array)$sportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('home')); ?>?sport=<?php echo e($sport['id'] ?? ''); ?>"
               class="sport-pill <?php echo e($sportId == ($sport['id'] ?? '') ? 'active' : ''); ?>">
                <?php echo e($sport['name'] ?? 'Sport'); ?>

            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <?php $liveData = $liveMatches['data'] ?? $liveMatches; ?>
    <section class="matches-section mb-5">
        <div class="section-header d-flex justify-content-between align-items-center mb-3">
            <h2 class="section-title">
                <span class="live-indicator"></span>
                <span class="live-badge-text">LIVE</span> Matches
                <?php if(!empty($liveData)): ?>
                    <span class="badge bg-danger ms-2"><?php echo e(count((array)$liveData)); ?></span>
                <?php endif; ?>
            </h2>
        </div>
        <?php if(!empty($liveData)): ?>
            <div class="matches-grid">
                <?php $__currentLoopData = (array)$liveData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.match-card', ['match' => $match, 'isLive' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="bi bi-broadcast"></i>
                <p>No live matches at the moment. Check back soon!</p>
            </div>
        <?php endif; ?>
    </section>

    
    <div class="ad-zone ad-in-article my-4">
        <?php echo app(\App\Services\AdManager::class)->renderSlot('in-article'); ?>

    </div>

    
    <?php $upcomingData = $upcomingMatches['data'] ?? $upcomingMatches; ?>
    <section class="matches-section mb-5">
        <div class="section-header d-flex justify-content-between align-items-center mb-3">
            <h2 class="section-title"><i class="bi bi-calendar-event text-info"></i> Upcoming Matches</h2>
        </div>
        <?php if(!empty($upcomingData)): ?>
            <div class="matches-grid">
                <?php $__currentLoopData = (array)$upcomingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.match-card', ['match' => $match, 'isLive' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="bi bi-calendar"></i>
                <p>No upcoming matches scheduled yet.</p>
            </div>
        <?php endif; ?>
    </section>

    
    <?php $finishedData = $finishedMatches['data'] ?? $finishedMatches; ?>
    <section class="matches-section mb-5">
        <div class="section-header d-flex justify-content-between align-items-center mb-3">
            <h2 class="section-title"><i class="bi bi-check2-circle text-success"></i> Recent Results</h2>
        </div>
        <?php if(!empty($finishedData)): ?>
            <div class="matches-grid">
                <?php $__currentLoopData = (array)$finishedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.match-card', ['match' => $match, 'isLive' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="bi bi-archive"></i>
                <p>No recent results available.</p>
            </div>
        <?php endif; ?>
    </section>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Auto-refresh live matches every 60 seconds
if (document.querySelector('.live-matches-section')) {
    setInterval(() => {
        fetch(window.location.href)
            .then(r => r.text())
            .then(() => { /* Update only live section via AJAX in production */ });
    }, 60000);
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\lebo\Downloads\lavarel sports\resources\views/home/index.blade.php ENDPATH**/ ?>